<?php
/**
 * Praktikum DBWT. Autoren:
 * Antonia, Badelt, 3728150
 * Alice, Kelberer, 3731224
 */

function addieren($a, $b = 0) {
    return $a + $b;
}
