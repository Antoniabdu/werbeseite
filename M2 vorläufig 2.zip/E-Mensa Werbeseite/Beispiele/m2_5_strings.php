<?php
/**
 * Praktikum DBWT. Autoren:
 * Antonia, Badelt, 3728150
 * Alice, Kelberer, 3731224
 */

$satz = "Hier wird ein Zeichen ausgetauscht. \n";
echo str_replace("Zeichen", "Wort", $satz);
// Ausgabe: "Hier wird ein Wort augetauscht."

echo str_repeat ("x" , 5);
// Ausgabe: xxxxx
echo "\n";

echo substr('Ein Teil' , 4);
//Ausgabe: Teil
echo "\n";

echo substr('Ein Teil', 2, -3);
//Ausgabe: n T
echo "\n";

$satz1 = "   Dieser Satz wird abgeschnitten.   ";
echo trim($satz1); //Ausgabe: "Dieser Satz wird abgeschnitten."
echo ltrim($satz1); //Ausgabe: "Dieser Satz wird abgeschnitten.   "
echo rtrim($satz1); //Ausgabe: "   Dieser Satz wird abgeschnitten."
echo "\n";

echo "Dies" . "ist" . "eine" . "String" . "Konkatenation";
//Ausgabe: DiesisteineStringKonkatenation
