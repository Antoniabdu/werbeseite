<?php
/**
 * Praktikum DBWT. Autoren:
 * Antonia, Badelt, 3728150
 * Alice, Kelberer, 3731224
 */
include('m2_6a_standardparameter.php');

echo addieren('2', '4') . "\n";
echo addieren('5') . "\n";
echo addieren('-5');
