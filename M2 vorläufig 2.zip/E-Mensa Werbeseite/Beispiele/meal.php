<?php

/**
 * Praktikum DBWT. Autoren:
 * Antonia, Badelt, 3728150
 * Alice, Kelberer, 3731224
 */
const GET_PARAM_MIN_STARS = 'search_min_stars';
const GET_PARAM_SEARCH_TEXT = 'search_text';

/**
 * List of all allergens.
 */
$allergens = [
    11 => 'Gluten',
    12 => 'Krebstiere',
    13 => 'Eier',
    14 => 'Fisch',
    17 => 'Milch'
];

$meal = [
    'name' => 'Süßkartoffeltaschen mit Frischkäse und Kräutern gefüllt',
    'description' => 'Die Süßkartoffeln werden vorsichtig aufgeschnitten und der Frischkäse eingefüllt.',
    'price_intern' => 2.90,
    'price_extern' => 3.90,
    'allergens' => [11, 13],
    'amount' => 42  // Number of available meals
];


$ratings = [
    [   'text' => 'Die Kartoffel ist einfach klasse. Nur die Fischstäbchen schmecken nach Käse. ',
        'author' => 'Ute U.',
        'stars' => 2 ],
    [   'text' => 'Sehr gut. Immer wieder gerne',
        'author' => 'Gustav G.',
        'stars' => 4 ],
    [   'text' => 'Der Klassiker für den Wochenstart. Frisch wie immer',
        'author' => 'Renate R.',
        'stars' => 4 ],
    [   'text' => 'Kartoffel ist gut. Das Grüne ist mir suspekt.',
        'author' => 'Marta M.',
        'stars' => 3 ]
];

$showRatings = [];
if (!empty($_GET[GET_PARAM_SEARCH_TEXT])) {
    $searchTerm = $_GET[GET_PARAM_SEARCH_TEXT];
    foreach ($ratings as $rating) {
        if (stripos($rating['text'], $searchTerm) !== false) { //c) stripos statt strpos
            $showRatings[] = $rating;
        }
    }
} else if (!empty($_GET[GET_PARAM_MIN_STARS])) {
    $minStars = $_GET[GET_PARAM_MIN_STARS];
    foreach ($ratings as $rating) {
        if ($rating['stars'] >= $minStars) {
            $showRatings[] = $rating;
        }
    }
} else {
    $showRatings = $ratings;
}

function calcMeanStars(array $ratings) : float {
    $sum = 0;                                               //d) logischen Fehler korrigieren. Bei 0 Anfangen anstatt bei 1
    foreach ($ratings as $rating) {
        $sum += $rating['stars'] / count($ratings);
    }
    return $sum;
}


$translations = [
    'de' => [
        'title' => 'Gericht: ' . $meal['name'],                // g) Übersetzung für Deutsch und Englisch
        'description_label' => 'Beschreibung:',
        'price_label_intern' => 'Der Preis intern:',
        'price_label_extern' => 'Der Preis extern:',
        'allergens_label' => 'Allergene',
        'reviews_label' => 'Bewertungen (Insgesamt: ',
        'search_label' => 'Filter:',
        'submit_button' => 'Suchen'
    ],
    'en' => [
        'title' => 'Dish: ' . $meal['name'],
        'description_label' => 'Description:',
        'price_label_intern' => 'Internal price:',
        'price_label_extern' => 'External price:',
        'allergens_label' => 'Allergens',
        'reviews_label' => 'Reviews (Overall: ',
        'search_label' => 'Filter:',
        'submit_button' => 'Search'
    ]
];


$lang = $_GET['sprache'] ?? 'de';                               // g) Sprache per GET-Parameter
?>


<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8"/>
    <title><?php echo $translations[$lang]['title']; ?></title>
    <style>
        * {
            font-family: Arial, serif;
        }
        .rating {
            color: darkgray;
        }
    </style>
</head>
<body>

<a href="?sprache=de">Deutsch</a>                               <!-- g) Sprachwahl Links -->
<a href="?sprache=en">English</a>

<h1><?php echo $translations[$lang]['title']; ?></h1>


<?php
if (!isset($_GET['show_description']) || $_GET['show_description'] != '0') {   // e) Beschreibung ein- und ausblenden nach GET Parameter
    echo "<p>Beschreibung: " . $meal['description'] . "</p>";
}   // ab ? Löschen und show_description=0 einfügen



// h) Preise anzeigen
echo $translations[$lang]['price_label_intern'] . " " . number_format($meal['price_intern'], 2, ',' , '') . "€";
echo "<br>";
echo $translations[$lang]['price_label_extern'] . " " . number_format($meal['price_extern'], 2, ',' , '') . "€";
?>

<h2><?php echo $translations[$lang]['allergens_label']; ?></h2>
<ul>
    <?php
    foreach ($meal['allergens'] as $allergen) {
        echo "<li>" . $allergens[$allergen] . "</li>";
    }
    ?>
</ul>

<h1><?php echo $translations[$lang]['reviews_label']; ?> <?php echo calcMeanStars($ratings); ?>)</h1>
<form method="get">
    <label for="search_text"><?php echo $translations[$lang]['search_label']; ?>:</label>  <!-- Wert nicht verlieren -->
    <input id="search_text" type="text" name="search_text" value="<?php echo htmlspecialchars($_GET['search_text'] ?? ''); ?>">
    <input type="submit" value="<?php echo $translations[$lang]['submit_button']; ?>">
</form>
<table class="rating">
    <thead>
    <tr>
        <td>Text</td>
        <td>Sterne</td>
    </tr>
    </thead>
    <tbody>
    <?php
    foreach ($showRatings as $rating) {
        echo "<tr><td class='rating_text'>{$rating['text']}</td>
                      <td class='rating_stars'>{$rating['stars']}</td>
                      <td class='rating_author'>{$rating['author']}</td>  
                  </tr>";                                                           // a) Autor mit ausgeben
    }
    ?>
    </tbody>
</table>
</body>
</html>