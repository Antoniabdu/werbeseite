<?php

// 1. Suchwort holen
$suchwort = isset($_GET['suche']) ? $_GET['suche'] : '';

// 2. Wenn ein Suchwort angegeben wurde
if ($suchwort !== '') {
    // 3. Datei einlesen (jede Zeile als Element im Array)
    $zeilen = file("en.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    $gefunden = false;

    // 4. Durch jede Zeile gehen und nach dem Wort suchen
    foreach ($zeilen as $zeile) {
        // Trennen in Schlüssel und Übersetzung
        $teile = explode(":", $zeile, 2);

        if (count($teile) === 2 && trim($teile[0]) === $suchwort) {
            echo "Übersetzung von <b>$suchwort</b>: " . htmlspecialchars($teile[1]);
            $gefunden = true;
            break;
        }
    }

    // 5. Wenn nichts gefunden wurde
    if (!$gefunden) {
        echo "Das gesuchte Wort <b>" . htmlspecialchars($suchwort) . "</b> ist nicht enthalten.";
    }
} else {
    echo "Bitte geben Sie ein Suchwort mit <code>?suche=...</code> in der URL an.";
}

?>
