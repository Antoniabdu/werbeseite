<?php


$meals = [
    [
        'name' => 'Rindfleisch mit Bambus, Kaiserschoten und rotem Paprika, dazu Mie Nudeln',
        'price_intern' => 3.50,
        'price_extern' => 6.20,
        'image' => 'Rindfleisch_MieNudeln.jpg'
    ],
    [
        'name' => 'Spinatrisotto mit kleinen Samosateigecken und gemischter Salat',
        'price_intern' => 2.90,
        'price_extern' => 5.30,
        'image' => 'Spinatrisotto.jpg'

    ],
    [
        'name' => 'Hähnchenbrust in Erdnuss-Kokos-Soße mit Duftreis und Sesamkernen',
        'price_intern' => 3.70,
        'price_extern' => 4.90,
        'image' => 'Erdnuss_Hähnchen.jpg'

    ],
    [
        'name' => 'Veganes Thai-Gemüse mit Tofu und Jasminreis in rotem Curry',
        'price_intern' => 3.10,
        'price_extern' => 3.90,
        'image' => 'Thai_curry.jpg'
    ],
    [
        'name' => 'Lachsfilet auf Zitronenrisotto mit grünem Spargel',
        'price_intern' => 4.20,
        'price_extern' => 6.30,
        'image' => 'lachs_zitronenrisotto_spargel.jpg'

    ]
];
?>
